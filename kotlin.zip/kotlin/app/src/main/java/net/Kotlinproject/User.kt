package net.Kotlinproject

data class User(
    val name: String,
    val username: String,
    val email: String,
    val phone: String,
    val website: String
)