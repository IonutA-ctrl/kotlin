package net.Kotlinproject
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_settings.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.Dispatchers.Main
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class SettingsFragment : Fragment()  {
    private val RESULT_1 = "Coroutines 1"
    private val RESULT_2 = "Coroutines 2"
    private val WAITTEXT = "loading.."
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        button1.setOnClickListener {

            CoroutineScope(IO).launch {
                fakeApiRequest()
            }
        }
        button2.setOnClickListener {
            textView1.setText("Cleared!")
        }
    }
    private fun setNewText(input: String){
        val newText = "" +"\n$input"
        textView1.text = newText
    }
    private suspend fun setTextOnMainThread(input: String) {
        withContext (Main) {
            setNewText(input)
        }
    }

    private suspend fun fakeApiRequest() {
        logThread("fakeApiRequest")
        val result1 = getResult1FromApi() // wait until job is done
        if ( result1.equals(RESULT_1)) {
            setTextOnMainThread(RESULT_1)
            val result3 = getResult3FromApi() // wait until job is done
            if (result3.equals(WAITTEXT)) {
                setTextOnMainThread(WAITTEXT)
                val result2 = getResult2FromApi() // wait until job is done
                if (result2.equals(RESULT_2)) {
                    setTextOnMainThread(RESULT_2)
                } else {
                    setTextOnMainThread("Couldn't get coroutines 2")
                }
            } else {
                setTextOnMainThread("Couldn't get loading sentence")
            }
        } else {
            setTextOnMainThread("Couldn't get Coroutines 1")
        }
    }


    private suspend fun getResult1FromApi(): String {
        logThread("getResult1FromApi")
        delay(1000) // Does not block thread. Just suspends the coroutine inside the thread
        return RESULT_1
    }

    private suspend fun getResult2FromApi(): String {
        logThread("getResult2FromApi")
        delay(2000)
        return RESULT_2
    }
    private suspend fun getResult3FromApi(): String {
        logThread("getResult3FromApi")
        delay(2000)
        return WAITTEXT
    }
    private fun logThread(methodName: String){
        println("debug: ${methodName}: ${Thread.currentThread().name}")
    }
}

