package net.Kotlinproject

import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET(value = "/users")
    fun fetchAllUsers() : Call<List<User>>
}